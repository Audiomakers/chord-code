# CHORD CODE PRO 1.1.1

Plugin de harmonia da Audio Makers desenvolvido em C++20 e JUCE 8.

## Formatos

- Windows x64: VST3;
- macOS 10.15 ou superior: VST3 e Audio Unit universais (Intel e Apple Silicon);
- macOS universal: Apple Silicon (`arm64`) e Intel (`x86_64`);
- não há target Standalone.

## Recursos principais

- progressões de 2, 4 ou 8 acordes;
- locks individuais e variações por acorde;
- voicings padrão, fechado, aberto e invertido;
- ritmos Reto, Humanize, Strum e Arpejo;
- exportação e arraste de MIDI;
- sincronização com o BPM do host;
- preview interno com síntese e samples incorporados;
- histórico e memória antirrepetição.

## Compilação dos testes do motor

```bash
cmake -S . -B build-core \
  -DCMAKE_BUILD_TYPE=Release \
  -DCCP_FETCH_JUCE=OFF
cmake --build build-core --config Release --target chordcode_pro_tests
ctest --test-dir build-core -C Release --output-on-failure
```

## Build macOS local

Em um Mac com Xcode e CMake:

```bash
./scripts/build-macos-installer.sh
./scripts/validate-macos-build.sh
```

O build gera:

- `Chord Code Pro.vst3`;
- `Chord Code Pro.component`;
- `Chord Code Pro 1.1.1 macOS.pkg`.

## GitHub Actions

- **Build macOS plugins:** compila e valida automaticamente um build universal
  de teste, sem exigir certificados Apple.
- **Release signed macOS installer:** assina, notariza, aplica o ticket da Apple
  e publica o instalador em uma release privada.

As instruções de certificados e secrets estão em
[`Packaging/macOS/README.md`](Packaging/macOS/README.md).

## Identidade do plugin

- produto: `Chord Code Pro`;
- bundle ID: `com.audiomakers.chordcodepro`;
- manufacturer code: `AuMk`;
- plugin code: `CcPr`;
- categoria: Instrument / Synth.

Certificados Apple, senhas, arquivos `.p12`, builds e instaladores gerados não
devem ser adicionados ao repositório.
