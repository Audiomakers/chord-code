$ErrorActionPreference = 'Stop'
cmake -S "$PSScriptRoot\.." -B "$PSScriptRoot\..\build" -G "Visual Studio 17 2022" -A x64
cmake --build "$PSScriptRoot\..\build" --config Release --target ChordCodeMini_VST3 chordcode_tests
ctest --test-dir "$PSScriptRoot\..\build" -C Release --output-on-failure
Write-Host "VST3: build\ChordCodeMini_artefacts\Release\VST3\Chord Code Mini.vst3"
